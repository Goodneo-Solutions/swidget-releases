package ca.superroute.swidget

import ca.superroute.sapp.ui.Obj
import ca.superroute.sapp.ui.obj
import ca.superroute.slocker.ui.LockerSelection

/**
 * What a widget tells the app (SWIDGET-SPEC.md §3), the same set on every platform. A widget never navigates: links,
 * files, payments and sign-in belong to the app.
 */
sealed class SwidgetEvent {
    /** The event's name as the specification spells it (`ready`, `select`, …, `signInRequired`, `openUrl`, `error`). */
    abstract val name: String

    /** The event's detail with the specification's field names. */
    abstract val detail: Map<String, Any?>

    /** The widget is drawn. */
    data class Ready(val widget: String, val type: String, val transport: String = "app", val preview: Boolean = false) : SwidgetEvent() {
        override val name = "ready"
        override val detail get() = linkedMapOf("widget" to widget, "type" to type, "transport" to transport, "preview" to preview)
    }

    /** A pickup point was chosen: the row as answered, and the typed choice. */
    data class Select(val pickupPoint: Obj, val selection: LockerSelection) : SwidgetEvent() {
        override val name = "select"
        override val detail get() = mapOf("pickup_point" to pickupPoint)
    }

    /** A quote was answered. */
    data class Quoted(val quote: Obj) : SwidgetEvent() {
        override val name = "quoted"
        override val detail get() = mapOf("quote" to quote)
    }

    /** An order was placed: `guest_order` for a guest shipment, `order` for a signed-in order. */
    data class Created(override val detail: Map<String, Any?>) : SwidgetEvent() {
        override val name = "created"
    }

    /** A guest shipment was cancelled. */
    data class Cancelled(val guestOrder: Obj) : SwidgetEvent() {
        override val name = "cancelled"
        override val detail get() = mapOf("guest_order" to guestOrder)
    }

    /** A guest shipment's payment link is ready for the app to open. */
    data class Payment(val guestOrder: Obj, val payUrl: String) : SwidgetEvent() {
        override val name = "payment"
        override val detail get() = linkedMapOf("guest_order" to guestOrder, "pay_url" to payUrl)
    }

    /** The person must sign in (again); the app signs them in on its sApp client and the widget follows. */
    data object SignInRequired : SwidgetEvent() {
        override val name = "signInRequired"
        override val detail: Map<String, Any?> get() = emptyMap()
    }

    /** A page the app should open (`purpose` `link`). */
    data class OpenUrl(val url: String, val purpose: String) : SwidgetEvent() {
        override val name = "openUrl"
        override val detail get() = linkedMapOf("url" to url, "purpose" to purpose)
    }

    /** A file (a guest shipment's label) handed to the app to save or share. */
    class File(val filename: String, val mimeType: String, val bytes: ByteArray) : SwidgetEvent() {
        override val name = "file"
        override val detail: Map<String, Any?> get() = linkedMapOf(
            "filename" to filename, "mime_type" to mimeType, "base64" to java.util.Base64.getEncoder().encodeToString(bytes),
        )
    }

    /** A failed or refused call. */
    data class Error(val error: SwidgetError) : SwidgetEvent() {
        override val name = "error"
        override val detail get() = error.detail
    }
}

/**
 * Turns the kit's events into the widget's (SWIDGET-SPEC.md §3, "From the kit's events"): `quoted {quote}`,
 * `created {guestOrder}` (then `payment` when it has a `pay_url`), `created {order}`, `cancelled {guestOrder}`,
 * `openUrl {url}` (`payment` when it is the current guest order's `pay_url`, else `openUrl` with purpose `link`),
 * `file {filename, mimeType, base64}`, `select {location}`, `signInRequired`. Other kit events are not passed on.
 */
class SwidgetEventMapper {
    private var guestOrder: Obj? = null

    @Synchronized
    fun map(event: String, detail: Obj): List<SwidgetEvent> = when (event) {
        "quoted" -> listOf(SwidgetEvent.Quoted(detail["quote"].obj()))
        "created" -> {
            val order = detail["guestOrder"] as? Map<*, *>
            if (order != null) {
                @Suppress("UNCHECKED_CAST") val o = order as Obj
                guestOrder = o
                val pay = o["pay_url"] as? String
                listOfNotNull(SwidgetEvent.Created(mapOf("guest_order" to o)), pay?.takeIf { it.isNotEmpty() }?.let { SwidgetEvent.Payment(o, it) })
            } else {
                listOf(SwidgetEvent.Created(mapOf("order" to detail["order"])))
            }
        }
        "cancelled" -> {
            val o = detail["guestOrder"].obj()
            if (detail["guestOrder"] is Map<*, *>) guestOrder = o
            listOf(SwidgetEvent.Cancelled(o))
        }
        "openUrl" -> {
            val url = detail["url"] as? String
            val order = guestOrder
            when {
                url == null -> emptyList()
                order != null && order["pay_url"] == url -> listOf(SwidgetEvent.Payment(order, url))
                else -> listOf(SwidgetEvent.OpenUrl(url, "link"))
            }
        }
        "file" -> {
            val bytes = (detail["base64"] as? String)?.let { runCatching { java.util.Base64.getDecoder().decode(it) }.getOrNull() }
            if (bytes == null) emptyList() else listOf(SwidgetEvent.File(detail["filename"] as? String ?: "", detail["mimeType"] as? String ?: "application/octet-stream", bytes))
        }
        "select" -> {
            val location = detail["location"] as? Map<*, *>
            @Suppress("UNCHECKED_CAST")
            if (location == null) emptyList() else listOf(SwidgetEvent.Select(location as Obj, LockerSelection.of(location as Obj)))
        }
        "signInRequired" -> listOf(SwidgetEvent.SignInRequired)
        else -> emptyList()
    }
}

/** The strings of the widget's own states. */
object SwidgetStrings {
    /** The text for [key] in [language] (English, then the key, when missing), with `:name` placeholders filled. */
    fun text(key: String, language: String, vararg params: Pair<String, String>): String {
        var text = SWIDGET_STRING_TABLES[language]?.get(key) ?: SWIDGET_STRING_TABLES["en"]?.get(key) ?: key
        for ((name, value) in params) text = text.replace(":$name", value)
        return text
    }
}
