package ca.superroute.swidget

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.Operation
import ca.superroute.sapp.OperationAuth
import ca.superroute.sapp.OperationBody
import ca.superroute.sapp.SuperrouteException
import ca.superroute.sapp.ThemeTokens
import ca.superroute.sapp.ui.GuestQuote
import ca.superroute.sapp.ui.GuestShippingOrder
import ca.superroute.sapp.ui.LocalSuperroute
import ca.superroute.sapp.ui.ShippingOrderForm
import ca.superroute.sapp.ui.SuperrouteScope
import ca.superroute.sapp.ui.Tracking
import ca.superroute.sapp.ui.obj
import ca.superroute.sapp.ui.superroute
import ca.superroute.slocker.ui.LockerMap
import ca.superroute.slocker.ui.LockerMapPage
import ca.superroute.slocker.ui.LockerMapSource
import ca.superroute.slocker.ui.SrMapAdapter
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject

/** What a widget shows around the kit component. */
sealed class SwidgetPhase {
    data object Loading : SwidgetPhase()

    /** Drawn with the kit component. */
    data object Ready : SwidgetPhase()

    /** A sign-in order widget while nobody is signed in. */
    data object SignIn : SwidgetPhase()

    /** The calling app lacks a capability the kind needs (`unavailable` of the configuration). */
    data class Unavailable(val capabilities: List<String>) : SwidgetPhase()

    /** An unknown kind or a newer configuration than this package draws. */
    data object Unsupported : SwidgetPhase()

    /** The configuration could not be read; [SwidgetState.retry] reads it again. */
    data class Failed(val error: SwidgetError) : SwidgetPhase()
}

/** The state of one [Swidget]: the configuration, the phase, the language and look, and the events it raises. */
class SwidgetState(
    val widgetId: String,
    val client: SwidgetClient,
    private val appLocale: String? = null,
    private val device: List<String> = SwidgetLocale.device(),
    var onEvent: (SwidgetEvent) -> Unit = {},
    private val appMode: String? = null,
    private val accent: String? = null,
) {
    var phase by mutableStateOf<SwidgetPhase>(SwidgetPhase.Loading)
        private set
    var config by mutableStateOf<SwidgetConfig?>(null)
        private set

    /** The language the widget is drawn in. */
    var language by mutableStateOf(SwidgetLocale.resolve(appLocale, null, device))
        private set

    /** The look the widget is drawn with. */
    var look by mutableStateOf<SwidgetLook?>(null)
        private set
    private var readyRaised = false
    private val mapper = SwidgetEventMapper()

    fun emit(event: SwidgetEvent) {
        if (event is SwidgetEvent.Ready) {
            if (readyRaised) return
            readyRaised = true
        }
        onEvent(event)
    }

    /** A kit event, turned into the widget's events (SWIDGET-SPEC.md §3). */
    fun kit(event: String, detail: Map<String, Any?>) = mapper.map(event, detail).forEach(::emit)

    /** Reads the configuration (again: the Try again button). */
    suspend fun load() {
        phase = SwidgetPhase.Loading
        val result = client.load(widgetId, appLocale, appMode, accent, device)
        config = result.config
        language = result.language
        look = result.look
        phase = when (result.state) {
            "ready" -> if (result.config?.signInOrder == true && !client.sapp.isSignedIn()) SwidgetPhase.SignIn else SwidgetPhase.Ready
            "not_available" -> SwidgetPhase.Unavailable(result.config?.unavailable ?: emptyList())
            "unsupported" -> SwidgetPhase.Unsupported
            else -> SwidgetPhase.Failed(result.error ?: SwidgetError("network_error", 0, "", widgetId))
        }
        result.events.forEach(::emit)
    }

    suspend fun retry() = load()

    /**
     * A failed call of the kit component the widget draws (the scope's `onError`), raised as the widget's `error`
     * event. A preview's refused write (`preview_read_only`) is shown as a sample and is not an error (§2, §4).
     */
    fun kitError(error: Throwable) {
        if (error is SuperrouteException && error.code == "preview_read_only") return
        emit(SwidgetEvent.Error(SwidgetError.of(error, config?.id ?: widgetId)))
    }

    /** The app's session started or ended (sApp `onSessionChange`). */
    fun sessionChanged(signedIn: Boolean) {
        if (config?.signInOrder != true) return
        if (signedIn && phase == SwidgetPhase.SignIn) phase = SwidgetPhase.Ready
        else if (!signedIn && phase == SwidgetPhase.Ready) phase = SwidgetPhase.SignIn
    }

    /** The app must sign the person in (the Sign in button, or a call that found the session ended). */
    fun requestSignIn() = kit("signInRequired", emptyMap())

    /** The pickup point source for the widget's options: every place, or only lockers or only counters. */
    fun pickupSource(config: SwidgetConfig): LockerMapSource {
        val lockers = config.option("lockers") as? Boolean ?: true
        val counters = config.option("counters") as? Boolean ?: true
        if (lockers && counters) return LockerMapSource.PickupPoints
        val kind = if (lockers) "locker" else "counter"
        val sapp = client.sapp
        return LockerMapSource.Custom { query ->
            val answer = sapp.callOperation(
                GUEST_PICKUP_POINTS,
                mapOf(
                    "latitude" to query.latitude, "longitude" to query.longitude, "search" to query.search, "pickup" to query.pickup,
                    "return" to query.returnValue, "available" to query.available, "page" to query.page, "per_page" to query.perPage,
                    "X-Swidget" to config.id,
                ),
            )
            filterPickupPoints(LockerMapPage.of(answer), kind)
        }
    }
}

/** The guest pickup point read, described by hand (sApp's specs describe it; sLocker's own copy is internal). */
internal val GUEST_PICKUP_POINTS = Operation(
    method = "GET", path = "/app/v1/clients/{clientCode}/guest/pickup-points", auth = OperationAuth.KEY,
    query = listOf("latitude", "longitude", "search", "pickup", "return", "available", "page", "per_page"),
    body = OperationBody.NONE, headers = listOf("X-Swidget"),
)

/** A page with only the places of one kind (`locker` or `counter`; a row without a kind is a locker). */
internal fun filterPickupPoints(page: LockerMapPage, kind: String): LockerMapPage =
    LockerMapPage(page.items.filter { (if (it["kind"] == "counter") "counter" else "locker") == kind }, page.hasMore)

/**
 * A widget configured in the Superroute back office, loaded by its id and drawn from the sApp and sLocker kits
 * (WS13): tracking → `Tracking`, quote → `GuestQuote`, guest order → `GuestShippingOrder`, sign-in order →
 * `ShippingOrderForm`, pickup point → `LockerMap` on the client's pickup points.
 *
 * Put it inside a `SuperrouteScope` (it then uses that client) or pass [client]. The configuration's branding and
 * language are the defaults; [mode], [theme], [accent] and [locale] override them (WS17). Every failed call of the kit
 * component it draws is raised as an `error` event too.
 *
 * @param widgetId the widget's public id (12 characters).
 * @param client sWidget on the app's connection (`SWidget.app(…)` / `SWidget.forSapp(…)`); the enclosing
 *   `SuperrouteScope`'s client (with the Keystore cache) when null.
 * @param locale one of the 14 languages; else the widget's fixed language, else the device's.
 * @param mode `light`, `dark` or `auto`; else the branding's, else `auto`.
 * @param theme the app's theme tokens in place of the widget's branding; [accent] only replaces its primary colour.
 * @param latitude the pickup point picker's origin, with [longitude]; [map] is the app's own map (sLocker `SrMapAdapter`).
 * @param onEvent every event of SWIDGET-SPEC.md §3.
 */
@Composable
fun Swidget(
    widgetId: String,
    modifier: Modifier = Modifier,
    client: SwidgetClient? = null,
    locale: String? = null,
    mode: String? = null,
    theme: ThemeTokens? = null,
    accent: String? = null,
    latitude: Double? = null,
    longitude: Double? = null,
    map: SrMapAdapter? = null,
    onEvent: (SwidgetEvent) -> Unit = {},
) {
    val context = LocalContext.current
    val outer = LocalSuperroute.current
    val events by rememberUpdatedState(onEvent)
    val widgets = client ?: outer?.let { remember(it.env.client) { SwidgetClient(it.env.client, KeystoreSwidgetCache(context)) } }
    if (widgets == null) {
        LaunchedEffect(widgetId) { events(SwidgetEvent.Error(SwidgetError("client_required", 0, "Swidget needs a client or a SuperrouteScope.", widgetId))) }
        Text(SwidgetStrings.text("widget.unavailable", SwidgetLocale.resolve(locale, null)), modifier.padding(16.dp))
        return
    }
    val state = remember(widgetId, widgets, locale, mode, accent) { SwidgetState(widgetId, widgets, locale, appMode = mode, accent = accent) }
    state.onEvent = { events(it) }
    LaunchedEffect(state) { state.load() }
    DisposableEffect(state) {
        val stop = widgets.sapp.onSessionChange { signedIn -> state.sessionChanged(signedIn) }
        onDispose { stop() }
    }
    // The look's tokens carry the mode and the radius, so the kit draws dark and the corners itself; before the
    // configuration is read, the app's mode (else `auto`) already applies. An app's own theme replaces every token.
    val tokens = theme ?: state.look?.tokens
        ?: remember(mode) { ThemeTokens(JsonObject(emptyMap()), mode?.takeIf { it in SwidgetLook.MODES } ?: "auto") }
    SuperrouteScope(
        client = widgets.sapp, theme = tokens, locale = state.language,
        onSignInRequired = { state.requestSignIn() }, onError = { state.kitError(it) },
    ) {
        Box(modifier.testTag("swidget")) { SwidgetContent(state, latitude, longitude, map) }
    }
}

@Composable
private fun SwidgetContent(state: SwidgetState, latitude: Double?, longitude: Double?, map: SrMapAdapter?) {
    val s = superroute()
    val scope = rememberCoroutineScope()
    fun t(key: String, vararg params: Pair<String, String>) = SwidgetStrings.text(key, state.language, *params)
    when (val phase = state.phase) {
        SwidgetPhase.Loading -> Box(Modifier.fillMaxWidth().heightIn(min = 88.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(Modifier.semantics { contentDescription = s.t("common.loading") }.testTag("swidget-loading"))
        }
        SwidgetPhase.Unsupported -> StateView(t("widget.update_app"), tag = "swidget-unsupported")
        is SwidgetPhase.Unavailable -> StateView(t("widget.unavailable"), tag = "swidget-unavailable")
        SwidgetPhase.SignIn -> StateView(t("auth.sign_in_hint"), tag = "swidget-sign-in", action = t("auth.sign_in")) { state.requestSignIn() }
        is SwidgetPhase.Failed -> {
            val error = phase.error
            val text = when {
                error.code == "too_many_requests" -> t("common.too_many")
                error.code == "network_error" -> s.t("common.error_network")
                error.code in SwidgetError.INTEGRATION_CODES -> t("widget.unavailable")
                else -> s.t("common.error")
            }
            val detail = error.requestId?.let { t("widget.request_id", "id" to it) }
            // Refusals stay refused until the back office changes something; everything else may work on a second try.
            if (error.code in SwidgetError.INTEGRATION_CODES && error.status != 0) {
                StateView(text, detail, tag = "swidget-failed")
            } else {
                StateView(text, detail, tag = "swidget-failed", action = s.t("common.retry")) { scope.launch { state.retry() } }
            }
        }
        SwidgetPhase.Ready -> state.config?.let { Component(state, it, latitude, longitude, map) }
    }
}

@Composable
private fun Component(state: SwidgetState, config: SwidgetConfig, latitude: Double?, longitude: Double?, map: SrMapAdapter?) {
    when (config.kind) {
        SwidgetKind.TRACKING -> Tracking()
        SwidgetKind.QUOTE -> GuestQuote(
            lines = (config.option("lines") as? List<*>)?.filterIsInstance<String>(),
            country = config.country,
            onQuoted = { state.kit("quoted", mapOf("quote" to it)) },
        )
        SwidgetKind.ORDER -> if (config.signInOrder) {
            ShippingOrderForm(serviceCode = config.option("service_code") as? String, onCreated = { state.kit("created", mapOf("order" to it)) })
        } else {
            GuestShippingOrder(
                verificationChannel = config.option("guest_shipping").obj()["verification_channel"] as? String ?: "email",
                country = config.country,
                onCreated = { order, token -> state.kit("created", mapOf("guestOrder" to order, "orderToken" to token)) },
                onCancelled = { state.kit("cancelled", mapOf("guestOrder" to it)) },
                onOpenUrl = { state.kit("openUrl", mapOf("url" to it)) },
                onFile = { name, type, bytes ->
                    state.kit("file", mapOf("filename" to name, "mimeType" to type, "base64" to java.util.Base64.getEncoder().encodeToString(bytes)))
                },
            )
        }
        SwidgetKind.PICKUP_POINT -> {
            val source = remember(config) { state.pickupSource(config) }
            LockerMap(latitude = latitude, longitude = longitude, map = map, source = source, onSelect = { state.kit("select", mapOf("location" to it)) })
        }
    }
}

/** A state of the widget itself: a line of text, a detail line and one button. */
@Composable
private fun StateView(text: String, detail: String? = null, tag: String, action: String? = null, onAction: () -> Unit = {}) {
    val s = superroute()
    Column(Modifier.fillMaxWidth().padding(16.dp).testTag(tag), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, color = s.color("onSurface"), textAlign = TextAlign.Center)
        if (detail != null) Text(detail, color = s.color("muted"), fontSize = s.size("small"))
        if (action != null) {
            Button(
                onClick = onAction,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("$tag-action"),
                colors = ButtonDefaults.buttonColors(containerColor = s.color("primary"), contentColor = s.color("onPrimary")),
            ) { Text(action) }
        }
    }
}

