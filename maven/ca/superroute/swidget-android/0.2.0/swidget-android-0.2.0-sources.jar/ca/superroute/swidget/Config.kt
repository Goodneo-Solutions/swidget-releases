package ca.superroute.swidget

import ca.superroute.sapp.SuperrouteException
import ca.superroute.sapp.ui.Obj
import ca.superroute.sapp.ui.obj
import ca.superroute.sapp.ui.plain
import ca.superroute.sapp.ui.text
import kotlinx.serialization.json.JsonElement
import java.util.Locale

/** The four kinds a widget can be (SWIDGET-SPEC.md §1). */
enum class SwidgetKind(val code: String) {
    TRACKING("tracking"),
    QUOTE("quote"),
    ORDER("order"),
    PICKUP_POINT("pickup_point");

    companion object {
        fun of(code: Any?): SwidgetKind? = entries.firstOrNull { it.code == code }
    }
}

/**
 * A widget's configuration as the back office set it: `GET /app/v1/clients/{clientCode}/swidgets/{widgetId}`
 * (`openapp.swidgets.show`), the answer's `data`.
 */
class SwidgetConfig private constructor(
    /** The widget's public id; events name the widget by it. */
    val id: String,
    val kind: SwidgetKind,
    val name: String,
    /** A fixed language (one of the 14), or null. */
    val locale: String?,
    /** The kind's options (`lines`, `order_mode`, `service_code`, `guest_shipping`, `lockers`, `counters`, …). */
    val options: Obj,
    /** `display_name`, `primary_color`, `logo_url`, … (the theme's defaults). */
    val branding: Obj,
    /** The client's country (ISO 3166-1 alpha-2); `CA` when the answer has none. */
    val country: String,
    val appCode: String?,
    val clientCode: String?,
    val configVersion: Int,
    /** `app` for this read. */
    val channel: String,
    /** The capabilities the calling app lacks for this kind; the widget shows "not available" while there are any. */
    val unavailable: List<String>,
    /** The answer's `data`, as plain values. */
    val raw: Obj,
    /** Whether this came from the 24-hour cache because Superroute could not be reached. */
    val fromCache: Boolean,
) {
    /** An option's value, or null. */
    fun option(name: String): Any? = options[name]

    /** Whether a sign-in order widget: the order is placed by the app's signed-in person. */
    val signInOrder: Boolean get() = kind == SwidgetKind.ORDER && option("order_mode") == "sign_in"

    companion object {
        /**
         * Reads the answer (`{result, data}`) or its `data`, as JSON or plain values. Throws `widget_unsupported` for
         * an unknown kind or a `config_version` above [SWidget.SUPPORTED_CONFIG_VERSION], and `invalid_response` for
         * anything that is not a configuration.
         */
        fun parse(answer: Any?, widgetId: String, fromCache: Boolean = false): SwidgetConfig {
            val root = (if (answer is JsonElement) answer.plain() else answer).obj()
            val data = if (root["data"].obj()["widget"] is Map<*, *>) root["data"].obj() else root
            val widget = data["widget"] as? Map<*, *>
                ?: throw SwidgetError("invalid_response", 200, "The answer is not a widget configuration.", widgetId)
            @Suppress("UNCHECKED_CAST")
            widget as Map<String, Any?>
            val id = widget["id"]?.text()?.takeIf { it.isNotEmpty() } ?: widgetId
            val version = (data["config_version"] as? Number)?.toInt() ?: 1
            val kind = SwidgetKind.of(widget["type"])
            if (kind == null || version > SWidget.SUPPORTED_CONFIG_VERSION) {
                throw SwidgetError("widget_unsupported", 200, "This widget needs a newer version of sWidget.", id)
            }
            val country = data["country"] as? String ?: ""
            return SwidgetConfig(
                id = id,
                kind = kind,
                name = widget["name"] as? String ?: "",
                locale = (widget["locale"] as? String)?.takeIf { it in SwidgetLocale.LANGUAGES },
                options = widget["options"].obj(),
                branding = data["branding"].obj(),
                country = if (Regex("^[A-Z]{2}$").matches(country)) country else "CA",
                appCode = data["app_code"] as? String,
                clientCode = data["client_code"] as? String,
                configVersion = version,
                channel = data["channel"] as? String ?: "app",
                unavailable = (data["unavailable"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                raw = data,
                fromCache = fromCache,
            )
        }
    }
}

/** The 14 languages of Superroute and how a widget's language is chosen (SWIDGET-SPEC.md §6). */
object SwidgetLocale {
    val LANGUAGES = listOf("en", "chs", "cht", "de", "es", "fr", "it", "nl", "pt", "sr", "hu", "pl", "sk", "cs")

    /** One of the 14 for a device language tag (`zh-Hans-CN` → chs, `zh-TW` → cht, `pt-BR` → pt), or null. */
    fun fromDevice(tag: String): String? {
        val parts = tag.replace('_', '-').lowercase(Locale.ROOT).split('-')
        val first = parts.firstOrNull() ?: return null
        if (first == "zh") return if (parts.any { it in setOf("hant", "tw", "hk", "mo") }) "cht" else "chs"
        return first.takeIf { it in LANGUAGES && it != "chs" && it != "cht" }
    }

    /** The device's languages, most preferred first. */
    fun device(): List<String> = listOf(Locale.getDefault().toLanguageTag())

    /** The app's language wins over the widget's fixed language, which wins over the device's; English otherwise. */
    fun resolve(app: String?, widget: String?, device: List<String> = device()): String {
        if (app != null && app in LANGUAGES) return app
        if (widget != null && widget in LANGUAGES) return widget
        return device.firstNotNullOfOrNull(::fromDevice) ?: "en"
    }
}

/** A refused or failed widget call (SWIDGET-SPEC.md §4), as the `error` event carries it. */
class SwidgetError(
    /** `widget_not_found`, `widget_revoked`, `widget_not_enabled_for_app`, `widget_unsupported`, `network_error`, … */
    val code: String,
    /** The HTTP status (0 when Superroute could not be reached, 200 for a configuration the package cannot draw). */
    val status: Int,
    message: String,
    /** The widget the error belongs to. */
    val widget: String,
    /** Seconds to wait before trying again (429). */
    val retryAfter: Int? = null,
    val requestId: String? = null,
) : Exception(message) {
    /** The `error` event's detail. */
    val detail: Map<String, Any?>
        get() = linkedMapOf(
            "code" to code, "status" to status, "widget" to widget,
            "retry_after" to retryAfter, "request_id" to requestId,
        )

    override fun toString(): String = "SwidgetError($code, $status): $message"

    companion object {
        /** The codes a visitor sees only as "not available" (SWIDGET-SPEC.md §4). */
        val INTEGRATION_CODES = setOf(
            "origin_not_allowed", "invalid_app_key", "invalid_client", "widget_call_not_allowed", "capability_disabled",
            "app_context_not_found", "widget_not_found", "widget_not_enabled_for_app", "widget_revoked", "not_ready",
            "client_code_required", "invalid_response",
        )

        /** The code for a failed call: the server's own, else `network_error` (no answer), `too_many_requests` (429) or `http_<status>`. */
        fun code(status: Int, given: String?): String = given?.takeIf { it.isNotEmpty() } ?: when (status) {
            0 -> "network_error"
            429 -> "too_many_requests"
            else -> "http_$status"
        }

        /**
         * A failed sApp call as a widget error. `retry_after` is the answer body's, else on a 429 sApp's own
         * [SuperrouteException.retryAfter] (the answer's `Retry-After`).
         */
        fun of(error: Throwable, widget: String): SwidgetError = when (error) {
            is SwidgetError -> error
            is SuperrouteException -> SwidgetError(
                code(error.status, error.code), error.status, error.message ?: "", widget,
                retryAfter = (error.body.plain().obj()["retry_after"] as? Number)?.toInt() ?: error.retryAfter.takeIf { error.status == 429 },
                requestId = error.requestId,
            )
            else -> SwidgetError("network_error", 0, error.message ?: error.toString(), widget)
        }
    }
}

/**
 * The look a widget is drawn with (SWIDGET-SPEC.md §5): the app's `theme` (mode) and `accent` win over the branding's
 * `theme`, `corner_radius` and `primary_color`.
 */
class SwidgetLook(
    /** `light`, `dark` or `auto`. */
    val mode: String,
    /** The medium corner radius in points (0–24), or null for the kit's own. */
    val radius: Int?,
    /** The primary colour, `#RRGGBB`. */
    val primary: String,
    /** The kit's theme tokens: the branding with the primary colour, [mode] and [radius] applied. */
    val tokens: ca.superroute.sapp.ThemeTokens,
) {
    /** The look as the shared cases name it. */
    val detail: Map<String, Any?> get() = linkedMapOf("mode" to mode, "radius" to radius, "primary" to primary)

    companion object {
        val MODES = listOf("light", "dark", "auto")

        fun resolve(branding: Obj, mode: String? = null, accent: String? = null): SwidgetLook {
            val brand = branding.toMutableMap()
            if (accent != null && Regex("^#[0-9a-fA-F]{6}$").matches(accent)) brand["primary_color"] = accent
            val chosen = mode?.takeIf { it in MODES } ?: (brand["theme"] as? String)?.takeIf { it in MODES } ?: "auto"
            val r = brand["corner_radius"] as? Number
            val radius = r?.let { java.math.BigDecimal(it.toString()) }?.takeIf { it.stripTrailingZeros().scale() <= 0 && it >= java.math.BigDecimal.ZERO && it <= java.math.BigDecimal(24) }?.toInt()
            // The kit draws the mode (its dark palette, `auto` following the device) and the medium radius itself; the
            // widget's own choice is passed explicitly so the app's mode wins and the default stays `auto`.
            val tokens = ca.superroute.sapp.ThemeTokens(
                ca.superroute.sapp.ui.body(*brand.map { it.key to it.value }.toTypedArray()), chosen, radius?.toDouble(),
            )
            return SwidgetLook(chosen, radius, tokens.colors["primary"] ?: "#E02020", tokens)
        }
    }
}
