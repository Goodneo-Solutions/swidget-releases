package ca.superroute.swidget

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import ca.superroute.sapp.DEFAULT_BASE_URL
import ca.superroute.sapp.MemoryTokenStore
import ca.superroute.sapp.Operation
import ca.superroute.sapp.OperationAuth
import ca.superroute.sapp.OperationBody
import ca.superroute.sapp.PartnerClient
import ca.superroute.sapp.TokenStore
import ca.superroute.sapp.ui.obj
import ca.superroute.sapp.ui.plain
import ca.superroute.sapp.ui.toJson
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import java.math.BigDecimal
import okhttp3.OkHttpClient
import java.security.KeyStore
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * sWidget for Android: a widget configured in the Superroute back office, loaded by its id on the app's own sApp
 * connection (WS2) and drawn by [Swidget] from the sApp and sLocker Compose kits.
 *
 * ```
 * // On its own: sWidget makes the sApp partner connection.
 * val widgets = SWidget.app(context, appCode = "p_acme_parcels", clientCode = "k3m9q2", appKey = appKey)
 * // Beside an sApp client the app already has: one sign-in for both.
 * val widgets = SWidget.forSapp(context, sr)
 *
 * Swidget(widgetId = "abc123def456", client = widgets) { event -> … }
 * ```
 */
object SWidget {
    /** The package version; every sWidget package of a release carries the same one. */
    const val VERSION = "0.2.1"

    /** The highest `config_version` this package draws. */
    const val SUPPORTED_CONFIG_VERSION = 1

    /** How long the last good configuration is kept for drawing offline, in seconds. */
    const val CACHE_LIFETIME_SECONDS = 24L * 60 * 60

    /** A connection of its own: makes the sApp [PartnerClient] inside (sign the person in through `client.sapp`). */
    fun app(
        context: Context,
        appCode: String,
        clientCode: String,
        appKey: String,
        tokenStore: TokenStore = MemoryTokenStore(),
        baseUrl: String = DEFAULT_BASE_URL,
        locale: String? = null,
        deviceId: String? = null,
        cache: SwidgetCache = KeystoreSwidgetCache(context),
        http: OkHttpClient = OkHttpClient(),
    ): SwidgetClient = standalone(appCode, clientCode, appKey, tokenStore, baseUrl, locale, deviceId, cache, http, System::currentTimeMillis)

    internal fun standalone(
        appCode: String, clientCode: String, appKey: String, tokenStore: TokenStore, baseUrl: String, locale: String?, deviceId: String?,
        cache: SwidgetCache, http: OkHttpClient, now: () -> Long,
    ): SwidgetClient {
        val sapp = PartnerClient(
            appCode = appCode, clientCode = clientCode, appKey = appKey, tokenStore = tokenStore, baseUrl = baseUrl,
            locale = locale, deviceId = deviceId, http = http, now = now,
        )
        return SwidgetClient(sapp, cache, now)
    }

    /** sWidget over the app's existing sApp client: its signed-in person, its token store, its service provider. */
    fun app(context: Context, sapp: PartnerClient, cache: SwidgetCache = KeystoreSwidgetCache(context)): SwidgetClient = SwidgetClient(sapp, cache)

    /** The same as [app] with an sApp client. */
    fun forSapp(context: Context, sapp: PartnerClient, cache: SwidgetCache = KeystoreSwidgetCache(context)): SwidgetClient = SwidgetClient(sapp, cache)
}

/**
 * The widget configuration read, described by hand on the sApp core (WS12): the app key, never a widget key, and the
 * widget's id in `X-Swidget` (attribution only).
 */
internal val SWIDGET_SHOW = Operation(
    method = "GET", path = "/app/v1/clients/{clientCode}/swidgets/{widgetId}", auth = OperationAuth.KEY,
    query = emptyList(), body = OperationBody.NONE, headers = listOf("X-Swidget"),
)

/** What loading a widget came to (SWIDGET-SPEC.md §1, §7). */
class SwidgetLoad(
    /** `ready` (the kind is drawn), `not_available`, `unsupported` or `refused`. */
    val state: String,
    val config: SwidgetConfig?,
    val error: SwidgetError?,
    /** The language the widget is drawn in. */
    val language: String,
    val look: SwidgetLook?,
    /** The events raised while loading, in order. */
    val events: List<SwidgetEvent>,
) {
    val fromCache: Boolean get() = config?.fromCache ?: false
}

/**
 * Loads widgets for one app and service provider. Every call after the configuration is an ordinary call of the app
 * through [sapp] (WS9).
 */
class SwidgetClient(
    /** The sApp client underneath: sign-in, refresh, the session, the service provider and the locale. */
    val sapp: PartnerClient,
    val cache: SwidgetCache = MemorySwidgetCache(),
    private val now: () -> Long = System::currentTimeMillis,
) {

    /** The cache key of a widget: `swidget:config:<appCode>:<clientCode>:<widgetId>`. */
    fun cacheKey(widgetId: String): String = "swidget:config:${sapp.appCode}:${sapp.clientCode ?: ""}:$widgetId"

    /**
     * Reads a widget's configuration (`openapp.swidgets.show`), network first.
     *
     * - A good answer is kept (`{"saved_at", "config"}`); a newer `config_version` or an unknown kind throws
     *   `widget_unsupported` and is never kept.
     * - 404 and 410 drop what was kept and throw.
     * - Without an answer, on a 429 or a 5xx, the configuration kept less than 24 hours ago is answered, marked
     *   `fromCache`; a kept value that cannot be read is dropped.
     * - Any other refusal throws and keeps what was kept.
     *
     * Throws [SwidgetError] only.
     */
    suspend fun loadConfig(widgetId: String): SwidgetConfig {
        if (sapp.clientCode.isNullOrEmpty()) {
            throw SwidgetError("client_code_required", 0, "clientCode is required to load a widget.", widgetId)
        }
        val key = cacheKey(widgetId)
        val answer: JsonElement = try {
            sapp.callOperation(SWIDGET_SHOW, mapOf("widgetId" to widgetId, "X-Swidget" to widgetId))
        } catch (error: CancellationException) {
            throw error
        } catch (error: Throwable) {
            val failure = SwidgetError.of(error, widgetId)
            if (failure.status == 404 || failure.status == 410) {
                cache.remove(key)
            } else if (failure.status == 0 || failure.status == 429 || failure.status >= 500) {
                val kept = cache.read(key)
                if (kept != null) {
                    val entry = kept.plain().obj()
                    val saved = (entry["saved_at"] as? BigDecimal)?.takeIf { it.stripTrailingZeros().scale() <= 0 }?.toLong()
                    val config = if (saved != null && entry["config"] is Map<*, *>) {
                        runCatching { SwidgetConfig.parse(entry["config"], widgetId, fromCache = true) }.getOrNull()
                    } else null
                    if (config == null) {
                        cache.remove(key)
                    } else if (now() / 1000 - saved!! < SWidget.CACHE_LIFETIME_SECONDS) {
                        return config
                    }
                }
            }
            throw failure
        }
        val config = SwidgetConfig.parse(answer, widgetId)
        cache.write(key, mapOf("saved_at" to now() / 1000, "config" to config.raw).toJson())
        return config
    }

    /**
     * Loads a widget and works out how it is drawn: its state, language and look, and the events raised meanwhile
     * (`ready`, or `error`). [mode] is the app's light/dark choice (`light`, `dark`, `auto`), [accent] its primary
     * colour, [device] the device's languages, most preferred first.
     */
    suspend fun load(widgetId: String, locale: String? = null, mode: String? = null, accent: String? = null,
                     device: List<String> = SwidgetLocale.device()): SwidgetLoad {
        val config = try {
            loadConfig(widgetId)
        } catch (error: SwidgetError) {
            return SwidgetLoad(if (error.code == "widget_unsupported") "unsupported" else "refused", null, error,
                SwidgetLocale.resolve(locale, null, device), null, listOf(SwidgetEvent.Error(error)))
        }
        val language = SwidgetLocale.resolve(locale, config.locale, device)
        val look = SwidgetLook.resolve(config.branding, mode, accent)
        if (config.unavailable.isNotEmpty()) {
            val error = SwidgetError("capability_disabled", 200, "The app lacks: ${config.unavailable.joinToString(", ")}.", config.id)
            return SwidgetLoad("not_available", config, error, language, look, listOf(SwidgetEvent.Error(error)))
        }
        return SwidgetLoad("ready", config, null, language, look, listOf(SwidgetEvent.Ready(config.id, config.kind.code)))
    }
}

/**
 * Where the last good configuration of each app × client × widget is kept (SWIDGET-SPEC.md §1, §7, WS19): under
 * `swidget:config:<appCode>:<clientCode>:<widgetId>` the JSON value `{"saved_at": <unix seconds>, "config": <data>}`.
 * An app gives [KeystoreSwidgetCache] (the default) or its own secure storage.
 */
interface SwidgetCache {
    suspend fun read(key: String): JsonElement?
    suspend fun write(key: String, value: JsonElement)
    suspend fun remove(key: String)
}

/** Keeps configurations in memory only (tests, previews). */
class MemorySwidgetCache(entries: Map<String, JsonElement> = emptyMap()) : SwidgetCache {
    private val entries = ConcurrentHashMap(entries)
    override suspend fun read(key: String): JsonElement? = entries[key]
    override suspend fun write(key: String, value: JsonElement) { entries[key] = value }
    override suspend fun remove(key: String) { entries.remove(key) }
}

/**
 * Keeps configurations encrypted with an AES key that never leaves the Android Keystore, in the app's private
 * storage. Unreadable stored data counts as nothing kept.
 */
class KeystoreSwidgetCache(
    context: Context,
    private val keyAlias: String = "ca.superroute.swidget.cache",
    preferences: String = "ca.superroute.swidget",
) : SwidgetCache {
    private val prefs = context.applicationContext.getSharedPreferences(preferences, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getEntry(keyAlias, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return generator.generateKey()
    }

    override suspend fun read(key: String): JsonElement? = withContext(Dispatchers.IO) {
        val stored = prefs.getString(key, null) ?: return@withContext null
        runCatching {
            val (iv, data) = stored.split(':', limit = 2).map { Base64.decode(it, Base64.NO_WRAP) }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv)) }
            Json.parseToJsonElement(String(cipher.doFinal(data), Charsets.UTF_8))
        }.getOrElse { JsonPrimitive(stored) }
    }

    override suspend fun write(key: String, value: JsonElement) = withContext(Dispatchers.IO) {
        val text = value.toString()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val data = cipher.doFinal(text.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(key, Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(data, Base64.NO_WRAP)).apply()
    }

    override suspend fun remove(key: String) = withContext(Dispatchers.IO) {
        prefs.edit().remove(key).apply()
    }
}
